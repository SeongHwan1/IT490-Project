<?php
namespace PhpAmqpLib\Exception;

class AMQPChannelClosedException extends AMQPRuntimeException
{
}
