<?php
namespace PhpAmqpLib\Exception;

/**
 * @deprecated
 */
class AMQPProtocolConnectionException extends AMQPProtocolException
{
}
